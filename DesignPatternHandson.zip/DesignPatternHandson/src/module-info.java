/**
 * 
 */
/**
 * @author sunitp
 *
 */
module DesignPatternHandson {
}