package exam.loggerproblem;

import java.text.SimpleDateFormat;
import java.util.Date;

public class ProxyLogger implements ILogger {
	
	private ILogger originalLogger;
	private SimpleDateFormat dateFormat;
	
	public ProxyLogger(ILogger originalLogger) {
        this.originalLogger = originalLogger;
        this.dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    }

	@Override
	public void info(String msg) {
		String formattedMessage = addDateTimeToMessage(msg);
        originalLogger.info(formattedMessage);
	}

	@Override
	public void error(String msg) {
		String formattedMessage = addDateTimeToMessage(msg);
        originalLogger.error(formattedMessage);
    }
		
	
	
	private String addDateTimeToMessage(String message) {
        Date now = new Date();
        String formattedDate = dateFormat.format(now);
        return "[" + formattedDate + "] " + message;
    }

}
