package exam.loggerproblem;

public class LoggerUsage {
    public static void main(String[] args) {
        ILogger logger=new LoggerImpl();
        ILogger proxy=new ProxyLogger(logger);
        
       proxy.info("This is an info message.");
       proxy.error("This is an error message.");
    }
}
