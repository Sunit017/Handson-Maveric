package exam.productproblem;

import java.util.ArrayList;

import java.util.List;

public class ProductNewAdaptor extends OldProductServiceImpl implements INewProductService {

@Override

public ProductDetails getProductById(long id) {

Product product = super.findProductById(id);

return new ProductDetails(product.getName(), product.getPrice());

}

@Override

public List<ProductDetails> fetchAllProducts() {

return convertProductListToProductDetailsList(super.getAll());

}


private List<ProductDetails> convertProductListToProductDetailsList(List<Product> productList) {

List<ProductDetails> productDetails = new ArrayList<>();

for (Product product : productList) {

productDetails.add(new ProductDetails(product.getName(), product.getPrice()));

}

return productDetails;

}

}
