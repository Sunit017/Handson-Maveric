package exam.productproblem;

public interface INotification {
    void renders();
}
