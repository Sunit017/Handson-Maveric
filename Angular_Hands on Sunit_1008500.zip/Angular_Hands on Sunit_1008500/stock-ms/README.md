# Stock Management

 **stock.json is project directory for reference**

**npm install to install node modules for the project**

 **use json server and feed stock.json to it to verify data is correctly pull or sent to server**


      Uncommment methods in Stock Service and complete them


  
 **List Stocks**
      Lists all stocks , fetch data from server and render the details of all stocks
  
