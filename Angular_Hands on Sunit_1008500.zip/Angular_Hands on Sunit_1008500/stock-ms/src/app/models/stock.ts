export class Stock {
    id:string|undefined;
    stockName:string|undefined;
    price:number|undefined;
    quantity:number|undefined;
}
