import { Injectable } from '@angular/core';
import { Observable ,of} from 'rxjs';
import { Stock } from '../models/stock';
import { catchError, map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class StockService {

  constructor() { }

   fetchAllStocks():Observable<Stock[]>{

    return this.getStockData().pipe(
      catchError(error => {
        console.error('Error fetching stocks', error);
        return of([]);
      })
    );
   }
    private getStockData(): Observable<Stock[]> {
      const stocksJson = {
        "stocks": [
          {
            "id": "1",
            "stockName": "samsung",
            "quantity": 25,
            "price": 10000
          },
          {
            "id": "2",
            "stockName": "mototolla",
            "quantity": 12,
            "price": 20000
          },
          {
            "id": "3",
            "stockName": "htc",
            "quantity": 10,
            "price": 30000
          }
        ]
      };

      const stocks: Stock[] = stocksJson.stocks.map(stockData => {
        const stock: Stock = new Stock();
        stock.id = stockData.id;
        stock.stockName = stockData.stockName;
        stock.quantity = stockData.quantity;
        stock.price = stockData.price;
        return stock;
      });
  
      return of(stocks);
    }

    
    }



