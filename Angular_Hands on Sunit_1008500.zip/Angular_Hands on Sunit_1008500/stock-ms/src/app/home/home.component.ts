import { Component, OnInit } from '@angular/core';
import { Stock } from '../models/stock';
import { StockService } from '../services/stock.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  stocks: Stock[] = [];


  constructor(private stockService: StockService) { }

  ngOnInit(): void {
    this.stockService.fetchAllStocks()
    .subscribe(stocks => {
      this.stocks = stocks;
    });
}
  }


