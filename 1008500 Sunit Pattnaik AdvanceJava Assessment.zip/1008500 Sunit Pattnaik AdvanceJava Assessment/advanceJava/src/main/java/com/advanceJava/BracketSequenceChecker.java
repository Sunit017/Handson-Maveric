package com.advanceJava;
import java.util.*;

public class BracketSequenceChecker {
	public static boolean isBracketSequenceCorrect(String sequence) {
        Stack<Character> stack = new Stack<>();

        for (char ch : sequence.toCharArray()) {
            if (isOpenBracket(ch)) {
                stack.push(ch);
            } else if (isCloseBracket(ch)) {
                if (stack.isEmpty() || !isMatchingBracket(stack.pop(), ch)) {
                    return false;
                }
            }
        }

        return stack.isEmpty();
    }
	 private static boolean isOpenBracket(char ch) {
	        return ch == '(' || ch == '[' || ch == '{' || ch == '<';
	    }

	    private static boolean isCloseBracket(char ch) {
	        return ch == ')' || ch == ']' || ch == '}' || ch == '>';
	    }

	    private static boolean isMatchingBracket(char open, char close) {
	        return (open == '(' && close == ')')
	                || (open == '[' && close == ']')
	                || (open == '{' && close == '}')
	                || (open == '<' && close == '>');
	    }
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        int testCases = scanner.nextInt();
	        scanner.nextLine(); 

	        while (testCases > 0) {
	            String sequence = scanner.nextLine();
	            int result = isBracketSequenceCorrect(sequence) ? 1 : 0;
	            System.out.print(result + " ");
	            testCases--;
	        }
	    }
}
