package com.advanceJava;

import java.util.Arrays;

public class BuildingJumps {

    public static int calculateMinJumps(int[] heights, int maxJump) {
        int n = heights.length;

        if (n <= 1) {
            return 0; // No jumps needed if there is only one building or no buildings
        }

        int[] dp = new int[n];
        Arrays.fill(dp, Integer.MAX_VALUE);
        dp[0] = 0; // Minimum jumps to reach the first building is 0

        for (int i = 1; i < n; i++) {
            for (int j = Math.max(0, i - maxJump); j < i; j++) {
                if (Math.abs(heights[i] - heights[j]) <= maxJump) {
                    dp[i] = Math.min(dp[i], dp[j] + 1);
                }
            }
        }

        return (dp[n - 1] == Integer.MAX_VALUE) ? -1 : dp[n - 1];
    }

    public static void main(String[] args) {
        int[] heights = {3, 1, 5, 1, 4, 3};
        int maxJump = 2;
        int minJumps = calculateMinJumps(heights, maxJump);
        System.out.println(minJumps); 
    }
}

