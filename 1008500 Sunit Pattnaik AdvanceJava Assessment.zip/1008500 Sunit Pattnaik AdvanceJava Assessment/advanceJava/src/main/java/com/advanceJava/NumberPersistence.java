package com.advanceJava;

public class NumberPersistence {
	
	 public static int persistence(long num) {
	        int count = 0;
	        while (num >= 10) {
	            long product = 1;
	            while (num != 0) {
	                product *= num % 10;
	                num /= 10;
	            }
	            num = product;
	            count++;
	        }
	        return count;
	    }
	 public static void main(String[] args) {
	       
	        System.out.println(persistence(39));   
	        System.out.println(persistence(999));  
	        System.out.println(persistence(4));    
	    }

}
