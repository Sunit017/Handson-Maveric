package com.advanceJava;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TagContentExtractor {

    public static void extractValidContent(String text) {
        Pattern pattern = Pattern.compile("<(.+?)>([^<>]+)</\\1>");
        Matcher matcher = pattern.matcher(text);
        boolean found = false;

        while (matcher.find()) {
            System.out.println(matcher.group(2));
            found = true;
        }

        if (!found) {
            System.out.println("None");
        }
    }

    public static void main(String[] args) {
        String[] testCases = {
                "<h1>Nayeem loves football</h1>",
                "<h1><h1>Sanjay has no watch</h1></h1><par>So wait for a while</par>",
                "<Amee>safat codes like a ninja</amee>",
                "<SA premium>Imtiaz has library</SA premium>"
        };

        for (String testCase : testCases) {
            extractValidContent(testCase);
        }
    }
}

