package com.advanceJava;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class NumberPersistenceTest {

	@Test
    public void testPersistence() {
        assertEquals(3, NumberPersistence.persistence(39));
        assertEquals(4, NumberPersistence.persistence(999));
        assertEquals(0, NumberPersistence.persistence(4));
    }
}
