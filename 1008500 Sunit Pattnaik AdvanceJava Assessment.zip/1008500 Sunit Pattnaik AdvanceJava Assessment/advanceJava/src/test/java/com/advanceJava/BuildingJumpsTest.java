package com.advanceJava;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class BuildingJumpsTest {
	
	@Test
    public void testCalculateMinJumps() {
        int[] heights1 = {3, 1, 5, 1, 4, 3};
        int maxJump1 = 2;
        assertEquals(3, BuildingJumps.calculateMinJumps(heights1, maxJump1));

//        int[] heights2 = {2, 3, 4, 5};
//        int maxJump2 = 1;
//        assertEquals(-1, BuildingJumps.calculateMinJumps(heights2, maxJump2));

//        int[] heights3 = {1, 2, 3, 4};
//        int maxJump3 = 100;
//        assertEquals(3, BuildingJumps.calculateMinJumps(heights3, maxJump3));
    }

}
