package com.advanceJava;

import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;

public class CharacterCounterTest {

    @Test
    public void testCountCharacters() {
        String str1 = "aba";
        Map<Character, Integer> expected1 = new HashMap<>();
        expected1.put('a', 2);
        expected1.put('b', 1);
        assertEquals(expected1, CharacterCounter.countCharacters(str1));

        String str2 = "";
        Map<Character, Integer> expected2 = new HashMap<>();
        assertEquals(expected2, CharacterCounter.countCharacters(str2));

        String str3 = "Hello World";
        Map<Character, Integer> expected3 = new HashMap<>();
        expected3.put('H', 1);
        expected3.put('e', 1);
        expected3.put('l', 3);
        expected3.put('o', 2);
        expected3.put(' ', 1);
        expected3.put('W', 1);
        expected3.put('r', 1);
        expected3.put('d', 1);
        assertEquals(expected3, CharacterCounter.countCharacters(str3));
    }
}

