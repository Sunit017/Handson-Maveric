package com.advanceJava;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class BracketSequenceCheckerTest {
	
	 @Test
	    public void testIsBracketSequenceCorrect() {
	        assertTrue(BracketSequenceChecker.isBracketSequenceCorrect("(a+[b*c]-{d/3})"));
	        assertFalse(BracketSequenceChecker.isBracketSequenceCorrect("(a + [b * c) - 17]"));
	        assertFalse(BracketSequenceChecker.isBracketSequenceCorrect("(((a * x) + [b] * y) + c"));
	        assertTrue(BracketSequenceChecker.isBracketSequenceCorrect("auf(zlo)men [gy<psy>] four{s}"));
	    }

}
