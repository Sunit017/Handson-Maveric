package com.advanceJava;

import org.junit.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import static org.junit.Assert.assertEquals;

public class TagContentExtractorTest {

    @Test
    public void testExtractValidContent() {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        PrintStream printStream = new PrintStream(outputStream);
        System.setOut(printStream);

        TagContentExtractor.extractValidContent("<h1>Nayeem loves football</h1>");
        assertEquals("Nayeem loves football\n", outputStream.toString());

        outputStream.reset();

        TagContentExtractor.extractValidContent("<h1><h1>Sanjay has no watch</h1></h1><par>So wait for a while</par>");
        assertEquals("Sanjay has no watch\nSo wait for a while\n", outputStream.toString());

        outputStream.reset();

        TagContentExtractor.extractValidContent("<Amee>safat codes like a ninja</amee>");
        assertEquals("None\n", outputStream.toString());

        outputStream.reset();

        TagContentExtractor.extractValidContent("<SA premium>Imtiaz has library</SA premium>");
        assertEquals("Imtiaz has library\n", outputStream.toString());

        
        System.setOut(System.out);
    }
}

